# ================================================
# COPG Module Installation Script
# ================================================

INSTALL_SUCCESS=true

print_box_start() {
  ui_print "╔═════════════════════════════════╗"
  ui_print "                                 "
}

print_box_end() {
  ui_print "                                 "
  ui_print "╚═════════════════════════════════╝"
}

print_empty_line() {
  ui_print "                                 "
}

print_failure_and_exit() {
  local section="$1"
  print_empty_line
  ui_print " ✗ 错误!          "
  if [ "$section" = "binary" ]; then
    print_empty_line
    print_empty_line
    print_empty_line
  fi
  print_box_end
  exit 1
}

grep_prop() {
  local PROP_FILE="$1"
  local PROP_NAME="$2"
  if [ -f "$PROP_FILE" ]; then
    grep "^${PROP_NAME}=" "$PROP_FILE" | cut -d'=' -f2- | head -n 1
  else
    echo ""
  fi
}

print_module_version() {
  print_box_start
  ui_print "      ✦ COPG 模块版本 ✦    "
  print_empty_line
  MODULE_PROP="$MODPATH/module.prop"
  if [ -f "$MODULE_PROP" ]; then
    MODULE_VERSION=$(grep_prop "$MODULE_PROP" "version")
    MODULE_VERSION_CODE=$(grep_prop "$MODULE_PROP" "versionCode")
    if [ -n "$MODULE_VERSION" ]; then
      ui_print " ✔ 模块版本: $MODULE_VERSION "
      [ -n "$MODULE_VERSION_CODE" ] && ui_print " ✔ 版本号: $MODULE_VERSION_CODE "
    else
      ui_print " ✗ 无法读取模块版本! "
    fi
  else
    ui_print " ✗ module.prop 未找到或不存在!        "
  fi
  print_box_end
  print_empty_line
}

check_zygisk() {
  ZYGISK_NEXT_PATH="/data/adb/modules/zygisksu"
  REZYGISK_PATH="/data/adb/modules/rezygisk"

  print_box_start
  ui_print "      ✦ Zygisk 检测 ✦      "
  ui_print "      如果您是Magisk或分支应用，请打开Zygisk/如果您是KernelSU或APath用户请安装Zygisk类模块!      "
  print_empty_line

  DETECTED_ROOT_SOLUTIONS=""
  ROOT_SOLUTION_COUNT=0

  if command -v apd >/dev/null; then
    DETECTED_ROOT_SOLUTIONS="$DETECTED_ROOT_SOLUTIONS APatch"
    ROOT_SOLUTION_COUNT=$((ROOT_SOLUTION_COUNT + 1))
    ROOT_SOLUTION="APatch"
    MANAGER_NAME="APatch 管理器"
  fi

  if command -v ksud >/dev/null; then
    DETECTED_ROOT_SOLUTIONS="$DETECTED_ROOT_SOLUTIONS KernelSU"
    ROOT_SOLUTION_COUNT=$((ROOT_SOLUTION_COUNT + 1))
    if [ $ROOT_SOLUTION_COUNT -eq 1 ]; then
      ROOT_SOLUTION="KernelSU"
      MANAGER_NAME="KernelSU 管理器"
    fi
  fi

  if command -v magisk >/dev/null; then
    DETECTED_ROOT_SOLUTIONS="$DETECTED_ROOT_SOLUTIONS Magisk"
    ROOT_SOLUTION_COUNT=$((ROOT_SOLUTION_COUNT + 1))
    if [ $ROOT_SOLUTION_COUNT -eq 1 ]; then
      ROOT_SOLUTION="Magisk"
      MANAGER_NAME="Magisk 管理器"
    fi
  fi

  if [ $ROOT_SOLUTION_COUNT -gt 1 ]; then
    ui_print " ✗ 找到多个Root解决方案！"
    ui_print " ➤ 检测:$DETECTED_ROOT_SOLUTIONS"
    ui_print " ➤ 仅允许一个Root方案"
    print_failure_and_exit "zygisk"
  elif [ $ROOT_SOLUTION_COUNT -eq 0 ]; then
    ui_print " ✗ 不支持的方案!   "
    ui_print " ➤ 支持方案列表:          "
    ui_print " ➤ • Magisk v26.4+ (ReZygisk/Zygisk Next)"
    ui_print " ➤ • KernelSU v0.7.0+ (Zygisk Next)"
    ui_print " ➤ • APatch v1.0.7+ (Zygisk Next)"
    print_failure_and_exit "zygisk"
  else
    ui_print " ➔ Root 方案: $ROOT_SOLUTION "
  fi

  # ── Per-variant ACTIVE state ──────────────────────────────────────────────
  # A variant counts as active only if its module dir exists AND has no
  # `disable` marker. Each is checked independently, so a disabled variant can
  # never mask another that IS active (e.g. Zygisk Next disabled + ReZygisk on
  # → ReZygisk still wins). `disable` on one says nothing about the other.
  ZN_ACTIVE=false; RZ_ACTIVE=false
  [ -d "$ZYGISK_NEXT_PATH" ] && [ ! -f "$ZYGISK_NEXT_PATH/disable" ] && ZN_ACTIVE=true
  [ -d "$REZYGISK_PATH" ]    && [ ! -f "$REZYGISK_PATH/disable" ]    && RZ_ACTIVE=true
  ZYGISK_INSTALLED=false
  { [ -d "$ZYGISK_NEXT_PATH" ] || [ -d "$REZYGISK_PATH" ]; } && ZYGISK_INSTALLED=true

  # ── Magisk: built-in Zygisk must be OFF ───────────────────────────────────
  # ReZygisk / Zygisk Next replace Magisk's native Zygisk and only load when
  # the built-in one is disabled. If native Zygisk is ON they silently fail to
  # work even though the module dir is present — so block install and tell the
  # user to turn it off (instead of falsely reporting the variant "Active").
  if [ "$ROOT_SOLUTION" = "Magisk" ]; then
    ZYGISK_STATUS=$(magisk --sqlite "SELECT value FROM settings WHERE key='zygisk';" 2>/dev/null)
    if [ "$ZYGISK_STATUS" = "value=1" ]; then
      ui_print " ✗  Magisk：内置Zygisk已启用!"
      ui_print " ➤ 在Magisk设置中禁用本地Zygisk"
      ui_print " ➤ ReZygisk / Zygisk Next 需要关掉"
      print_failure_and_exit "zygisk"
    fi
  fi

  # ── Require an ACTIVE standalone Zygisk variant ───────────────────────────
  if $RZ_ACTIVE; then
    ui_print " ✔ $ROOT_SOLUTION: ReZygisk 确认    "
    print_box_end
    return
  elif $ZN_ACTIVE; then
    ui_print " ✔ $ROOT_SOLUTION: Zygisk Next 确认  "
    print_box_end
    return
  elif $ZYGISK_INSTALLED; then
    ui_print " ✗ $ROOT_SOLUTION: Zygisk 模块禁用!"
    ui_print " ➤ 启用 ReZygisk / Zygisk Next 在 $MANAGER_NAME"
    print_failure_and_exit "zygisk"
  else
    ui_print " ✗ $ROOT_SOLUTION: 未找到Zygisk方案"
    ui_print " ➤ 安装ReZygisk或Zygisk Next       "
    print_failure_and_exit "zygisk"
  fi
}

cleanup_unused_architectures() {
  ABI_LIST=$(getprop ro.product.cpu.abilist)
  
  # IMPORTANT: Check in order from most specific to least specific
  # x86_64 is the most specific (emulators with full compatibility)
  if echo "$ABI_LIST" | grep -q "x86_64"; then
    ui_print " 🧹 x86_64 模拟 - 保持所有架构"
    # Keep everything for Houdini compatibility
    ui_print " ✓ Kept: x86_64, x86, ARM64, ARM32"
  
  # x86 32-bit (rare)
  elif echo "$ABI_LIST" | grep -q "x86" && ! echo "$ABI_LIST" | grep -q "x86_64"; then
    ui_print " 🧹 x86 32位设备 - 保持 x86 + ARM32..."
    rm -f "$MODPATH/zygisk/arm64-v8a.so" "$MODPATH/zygisk/x86_64.so" 2>/dev/null
    ui_print " ✓ Kept: x86, ARM32"
  
  # ARM devices (phones, tablets)
  elif echo "$ABI_LIST" | grep -qE "arm64|armeabi|armv7|arm"; then
    ui_print " 🧹 ARM 设备 - 正在删除x86/x86_64库..."
    rm -f "$MODPATH/zygisk/x86.so" "$MODPATH/zygisk/x86_64.so" 2>/dev/null
    ui_print " ✓ Kept: ARM64 + ARM32"
  fi
  
  # Remove all controller source files (we only need 'controller')
  rm -f "$MODPATH/controller_arm64" "$MODPATH/controller_armv7" "$MODPATH/controller_x86" "$MODPATH/controller_x86_64" 2>/dev/null
}

print_module_version

if ! $BOOTMODE; then
  print_box_start
  ui_print "      ✦ 安装错来 ✦     "
  print_empty_line
  ui_print " ✗ Recovery 模式不支持!  "
  ui_print " ➤ Via安装 Magisk/KSU/APatch "
  print_failure_and_exit "initial"
fi

if [ "$API" -lt 26 ]; then
  print_box_start
  ui_print "      ✦ Installation Error ✦     "
  print_empty_line
  ui_print " ✗ 安卓版本过老!      "
  ui_print " ➤ 至少 Android 9.0+         "
  print_failure_and_exit "initial"
fi

if $INSTALL_SUCCESS; then
  check_zygisk || {
    INSTALL_SUCCESS=false
  }
fi

if $INSTALL_SUCCESS; then
  print_box_start
  ui_print "      ✦ 安装控制 ✦  "
  print_empty_line
  ui_print " ⚙ 正在检测设备架构 "

  ARM64_VARIANTS="arm64-v8a|armv8-a|arm64|aarch64"
  ARM32_VARIANTS="armeabi-v7a|armeabi|armv7-a|armv7l|armhf|arm"
  X86_64_VARIANTS="x86_64|amd64"
  X86_VARIANTS="x86|i386|i686"

  ABI_LIST=$(getprop ro.product.cpu.abilist)
  ui_print " 📜 支持 ABIs: $ABI_LIST"

  if $INSTALL_SUCCESS; then
    CONTROLLER_INSTALLED=false

    for ABI in $(echo "$ABI_LIST" | tr ',' ' '); do
      if echo "$ABI" | grep -qE "$ARM64_VARIANTS"; then
        if [ -f "$MODPATH/controller_arm64" ]; then
          mv "$MODPATH/controller_arm64" "$MODPATH/controller" || {
            ui_print " ✗ 重命名ARM64控制失败!  "
            print_failure_and_exit "binary"
          }
          chmod 0755 "$MODPATH/controller" || {
            ui_print " ✗ 无法设置权限（控制器）!  "
            print_failure_and_exit "binary"
          }
          ui_print " ✔ 已安装ARM64控制器     "
          ui_print " ➤ ($ABI)                        "
          CONTROLLER_INSTALLED=true
          
          rm -f "$MODPATH/controller_armv7" "$MODPATH/controller_x86" "$MODPATH/controller_x86_64" 2>/dev/null
          break
        fi
      elif echo "$ABI" | grep -qE "$ARM32_VARIANTS"; then
        if [ -f "$MODPATH/controller_armv7" ]; then
          mv "$MODPATH/controller_armv7" "$MODPATH/controller" || {
            ui_print " ✗    无法重命名ARM32控制器！  "
            print_failure_and_exit "binary"
          }
          chmod 0755 "$MODPATH/controller" || {
            ui_print " ✗ 无法设置权限（控制器）!  "
            print_failure_and_exit "binary"
          }
          ui_print " ✔ 已安装ARM32控制器     "
          ui_print " ➤ ($ABI)                        "
          CONTROLLER_INSTALLED=true
          
          rm -f "$MODPATH/controller_arm64" "$MODPATH/controller_x86" "$MODPATH/controller_x86_64" 2>/dev/null
          break
        fi
      elif echo "$ABI" | grep -qE "$X86_64_VARIANTS"; then
        if [ -f "$MODPATH/controller_x86_64" ]; then
          mv "$MODPATH/controller_x86_64" "$MODPATH/controller" || {
            ui_print " ✗ 无法重命名x86_64控制器!  "
            print_failure_and_exit "binary"
          }
          chmod 0755 "$MODPATH/controller" || {
            ui_print " ✗ 无法设置权限（控制器）!  "
            print_failure_and_exit "binary"
          }
          ui_print " ✔ 已安装X86_64个控制器     "
          ui_print " ➤ ($ABI)                        "
          CONTROLLER_INSTALLED=true
          
          rm -f "$MODPATH/controller_arm64" "$MODPATH/controller_armv7" "$MODPATH/controller_x86" 2>/dev/null
          break
        fi
      elif echo "$ABI" | grep -qE "$X86_VARIANTS"; then
        if [ -f "$MODPATH/controller_x86" ]; then
          mv "$MODPATH/controller_x86" "$MODPATH/controller" || {
            ui_print " ✗ 重命名x86控制器失败！  "
            print_failure_and_exit "binary"
          }
          chmod 0755 "$MODPATH/controller" || {
            ui_print " ✗ 无法设置权限（控制器）!  "
            print_failure_and_exit "binary"
          }
          ui_print " ✔ 已安装x86控制器     "
          ui_print " ➤ ($ABI)                        "
          CONTROLLER_INSTALLED=true
          
          rm -f "$MODPATH/controller_arm64" "$MODPATH/controller_armv7" "$MODPATH/controller_x86_64" 2>/dev/null
          break
        fi
      fi
    done

    if ! $CONTROLLER_INSTALLED; then
      ui_print " ✗ 未找到兼容的控制器！ "
      ui_print " ➤ Supported Architectures:      "
      ui_print " ➤ • ARM64 (arm64-v8a)          "
      ui_print " ➤ • ARM32 (armeabi-v7a)        "
      ui_print " ➤ • x86_64                     "
      ui_print " ➤ • x86                        "
      print_failure_and_exit "binary"
    fi
  print_box_end
  print_empty_line
fi

  if $INSTALL_SUCCESS; then
    chmod 0755 "$MODPATH/service.sh" 2>/dev/null
    chmod 0644 "$MODPATH/COPG.json" "$MODPATH/list.json" 2>/dev/null
    chmod 0444 "$MODPATH/cpuinfo_spoof" 2>/dev/null

    for file in "$MODPATH/COPG.json" "$MODPATH/list.json" "$MODPATH/cpuinfo_spoof" \
                "$MODPATH/service.sh"; do
      if [ -f "$file" ]; then
        chcon u:object_r:system_file:s0 "$file" 2>/dev/null
      fi
    done
    
    # Clean up unused architecture files to reduce module size
    cleanup_unused_architectures
  fi


  if $INSTALL_SUCCESS; then
    print_empty_line
    print_box_start
    ui_print " ✅ 模块已成功安装 "
    print_box_end
  fi
fi

if ! $INSTALL_SUCCESS; then
  exit 1
fi
